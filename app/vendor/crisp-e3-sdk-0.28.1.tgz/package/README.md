# CRISP SDK

TypeScript SDK for interacting with CRISP (Coercion-Resistant Impartial Selection Protocol) and the
CRISP server.

## Installation

```bash
npm install @crisp-e3/sdk
```

## Features

- **Round Management**: Fetch round details, token requirements, and voting parameters
- **Token Operations**: Query token balances and total supply at specific blocks
- **Merkle Tree Utilities**: Generate proofs for voter inclusion in the eligibility tree
- **Vote Proof Generation**: Create zero-knowledge proofs for votes and mask votes
- **Proof Verification**: Verify generated proofs using Noir circuits
- **Selectable Parameters**: preset bundles are separate entry points and can be loaded on demand

## Choosing a preset

Proving needs the BFV-shaped circuits, and those exist once per parameter set. They are not part of
the main entry point: the `secure-8192` set is far larger than `insecure-64`. Each preset has its
own subpath, so your bundler can pull only the one the round needs.

```ts
import { setCircuits } from '@crisp-e3/sdk'
import { loadCircuits } from '@crisp-e3/sdk/insecure-64' // or '@crisp-e3/sdk/secure-8192'

setCircuits(await loadCircuits())
```

Register once at start-up, before the first `prepareBallot`/`generateProof`. There is deliberately
no default: a ballot proved against the wrong parameters is rejected on chain rather than locally,
so `generateProof` throws a directed error instead of guessing.

In a browser, load it through a dynamic `import()` so the circuits become their own chunk and the
app boots without them:

```ts
const { loadCircuits } = await import('@crisp-e3/sdk/secure-8192')
setCircuits(await loadCircuits())
```

`verifyProof`, `encodeVote`, `decodeTally` and the round/token helpers need no preset. The
aggregation circuits they use are proof-shaped rather than polynomial-shaped, so a single artifact
covers every preset and ships in the main entry point.

## Usage

### CrispSDK Class (Recommended)

The `CrispSDK` class provides a convenient interface that automatically handles server communication
for fetching previous ciphertexts and checking slot status.

```typescript
import { CrispSDK } from '@crisp-e3/sdk'

const sdk = new CrispSDK(serverUrl)

// Generate a vote proof (automatically fetches previous ciphertext if needed)
const voteProof = await sdk.generateVoteProof({
  e3Id: 1n,
  vote: [100, 0], // one weight per option
  publicKey: publicKeyBytes,
  signature: '0x...',
  messageHash: '0x...',
  balance: 1000n,
  slotAddress: '0x...',
  merkleLeaves: [...],
})

// Generate a mask vote proof (automatically fetches previous ciphertext if needed)
const maskProof = await sdk.generateMaskVoteProof({
  e3Id: 1n,
  balance: 1000n,
  slotAddress: '0x...',
  publicKey: publicKeyBytes,
  merkleLeaves: [...],
})
```

### Standalone Functions

#### Get Round Details

```typescript
import { getRoundDetails, getRoundTokenDetails } from '@crisp-e3/sdk'

const roundDetails = await getRoundDetails(serverUrl, e3Id)
const tokenDetails = await getRoundTokenDetails(serverUrl, e3Id)
```

#### Get Token Balance and Supply

```typescript
import { getBalanceAt, getTotalSupplyAt, getTreeData } from '@crisp-e3/sdk'

const balance = await getBalanceAt(voterAddress, tokenAddress, snapshotBlock, chainId)
const totalSupply = await getTotalSupplyAt(tokenAddress, snapshotBlock, chainId)
const merkleLeaves = await getTreeData(serverUrl, e3Id)
```

#### Generate Vote Proof (Low-level)

```typescript
import { generateVoteProof } from '@crisp-e3/sdk'

const proof = await generateVoteProof({
  vote: [100, 0], // one weight per option
  publicKey: publicKeyBytes,
  signature: '0x...',
  messageHash: '0x...',
  balance: 1000n,
  slotAddress: '0x...',
  merkleLeaves: [...],
  previousCiphertext: previousCiphertextBytes, // optional
})
```

#### Generate Mask Vote Proof (Low-level)

```typescript
import { generateMaskVoteProof } from '@crisp-e3/sdk'

const maskProof = await generateMaskVoteProof({
  balance: 1000n,
  slotAddress: '0x...',
  publicKey: publicKeyBytes,
  merkleLeaves: [...],
  previousCiphertext: previousCiphertextBytes, // optional
})
```

#### Report Proving Progress

A ballot proof is five proofs in sequence, listed in `PROOF_STAGES`. `finishBallotProof`,
`finishMaskProof` and `CrispSDK.finishBallot` take an optional `onProgress`, called as each stage
starts:

```typescript
import { finishBallotProof } from '@crisp-e3/sdk'

const proof = await finishBallotProof(prepared, digest, signature, {
  onProgress: ({ stage, index, total }) => console.log(`${index + 1}/${total}: ${stage}`),
})
```

| Stage            | Circuit                    | What it proves                                                                                                                       |
| ---------------- | -------------------------- | ------------------------------------------------------------------------------------------------------------------------------------ |
| `encryption_ct0` | `user_data_encryption_ct0` | The ciphertext half that carries the ballot is a well-formed encryption of it                                                        |
| `encryption_ct1` | `user_data_encryption_ct1` | The other ciphertext half is well formed                                                                                             |
| `ballot`         | `crisp` / `crisp_onchain`  | A vote is signed by the slot owner and within voting power, or a mask is zero; the new slot ciphertext is the ballot plus the addend |
| `encryption`     | `user_data_encryption`     | Both halves verify and share the same encryption randomness                                                                          |
| `fold`           | `fold` / `fold_onchain`    | Encryption and ballot proofs cover the same ciphertext; outputs the key commitment the contract checks against the committee key     |

#### Verify Proof

```typescript
import { verifyProof } from '@crisp-e3/sdk'

const isValid = await verifyProof(proof)
```

#### Ballot Encoding and Decode Tally

Coefficient `o` of the message polynomial is the weight on option `o`. Every other coefficient up to
the BFV degree is zero. BFV adds ballots coefficient by coefficient, so the decrypted tally holds
one total per option. A weight is a non-negative integer below the BFV plaintext modulus `t`, and a
round has 2 to `MAX_VOTE_OPTIONS` options. `CRISPProgram` keeps every option total below `t`.

```typescript
import { encodeVote, decodeTally } from '@crisp-e3/sdk'

const coefficients = encodeVote([3, 0, 7]) // coefficient 0 = 3, coefficient 2 = 7, the rest 0

const tally = decodeTally(tallyBytes, numOptions)
// Returns: bigint[] — the first numOptions coefficients, one total per option
```

#### Cryptographic Utilities

```typescript
import { generatePublicKey, encryptVote, encodeSolidityProof } from '@crisp-e3/sdk'

const publicKey = generatePublicKey()
const encryptedVote = encryptVote(vote, publicKey)
const encodedProof = encodeSolidityProof(proof)
```

#### Merkle Tree Utilities

```typescript
import {
  generateMerkleProof,
  generateMerkleTree,
  hashLeaf,
  getAddressFromSignature,
} from '@crisp-e3/sdk'

const leaf = hashLeaf(address, balance)
const tree = generateMerkleTree(leaves)
const proof = generateMerkleProof(balance, address, merkleLeaves)
const address = await getAddressFromSignature(signature, messageHash)
```

#### State Utilities

```typescript
import { getPreviousCiphertext } from '@crisp-e3/sdk'

const head = await getPreviousCiphertext(serverUrl, e3Id, slotAddress)
// { ciphertext, index }, or undefined when the slot holds nothing usable (404).
// `index` is the entry a new input names as its parent. It is the end of the slot's chain of
// usable entries, not simply the newest one published: an entry whose bytes do not reproduce its
// commitment is never selected by the Secure Process, and never a valid parent.
```

#### Submission Status

A committed ballot counts only when the Secure Process selects it for its slot and its ciphertext is
published. An earlier ballot or mask that names the same parent takes the slot first.

```typescript
import {
  decodeInputIdentity,
  getInputSelection,
  getSubmissionStage,
  getVoteAvailability,
} from '@crisp-e3/sdk'

const identity = decodeInputIdentity(encodedProof)
const job = await getVoteAvailability(serverUrl, jobId)
const selection = await getInputSelection(serverUrl, e3Id, identity)
// undefined when the server has no record of the round (404).
const { stage, retryOffered } = getSubmissionStage({
  availability: job.status,
  selection: selection ?? null,
  now: Math.floor(Date.now() / 1000),
  commitmentDeadline,
})
// stage: awaiting_commitment | selection_pending | availability_pending | counted | excluded | failed
// retryOffered: true only for `excluded` before the commitment deadline.
```

#### Reading a Round From the Chain

Round readiness, the committee key and "does this slot already hold an entry" need no CRISP server.
Only ballot staging (`broadcastVote`, `getVoteAvailability`) does. A `CrispSDK` built without a
`serverUrl` runs these reads through its `rpcUrl`; its server-backed methods throw.

```typescript
import { CrispSDK } from '@crisp-e3/sdk'

const sdk = new CrispSDK({ rpcUrl }) // `new CrispSDK(serverUrl, rpcUrl)` still works
const round = { interfoldAddress, e3Id, chainId }

const state = await sdk.getRoundState(round)
// state.acceptingInputs: the key is published (`KeyPublished`) and now is within
// [inputWindow.start, commitmentDeadline), the checks `CRISPProgram.publishInput` makes.
// `commitmentDeadline` is earlier than `inputWindow.end` by the program's finalization window.

// Throws unless a candidate's recomputed BFV commitment equals the coordinator's. A candidate is
// only a hint that a committee member published, so never encrypt to an unchecked one.
const publicKey = await sdk.getCommitteePublicKey(round)

const { active, entries } = await sdk.getSlotStatus({ programAddress, e3Id, slot, chainId })
// `active` means the slot has a committed entry, not that its owner voted: anyone can mask a slot.
```

A page that only shows round status can import the same reads from `@crisp-e3/sdk/chain`, which
pulls in `viem` and nothing else: no wasm, no noir, no bb.js.

The log scans walk `eth_getLogs` in 5000-block chunks from the round's request (the key) or from the
opening of its input window (slot status), so they need an RPC that serves that history; many public
endpoints prune old logs. Pass `fromBlock` to narrow the scan.

#### Resolving a Slot Head Without the Server

A re-vote or mask has to name the slot's current head as its parent, and its ciphertext is an input
to the new ballot. `getSlotHead` resolves it from the chain, applying the Secure Process's rule
(`chain_head_per_slot`): walking the slot's entries in tree-index order, an entry becomes the head
when its bytes reproduce its on-chain commitment **and** it names the current head as its parent.
Ciphertext bytes come from a `DaReader`, and each answer is checked against the entry's on-chain
`keccak256` before use.

```typescript
import {
  CrispSDK,
  createAvailDaReader,
  createFallbackDaReader,
  createHttpDaReader,
} from '@crisp-e3/sdk'

const daReader = createFallbackDaReader(
  createAvailDaReader({ rpcUrl: 'https://turing-rpc.avail.so/rpc' }), // entries with an Avail receipt
  createHttpDaReader('https://<store>'), // GET <store>/objects/<keccak256>: entries still waiting for one
)

const sdk = new CrispSDK({ rpcUrl, daReader }) // no serverUrl needed
const prepared = await sdk.prepareBallot({ e3Id, programAddress, chainId, slotAddress, ...ballot })
```

- Which reader serves which entry: `InputCommitted` reserves the tree index at once, but the Avail
  block (`availabilityBlock`) only appears with `InputPublished`, which can trail by hours. The
  Avail reader needs it, so an entry still waiting needs a store that holds bytes by content hash.
  The CRISP server's staging route (`/availability` under its base URL, passed to
  `createHttpDaReader`) is one.
- It fails rather than guesses. An unreadable entry that could be the head, or bytes that fail the
  hash check, throw: naming a stale parent gets the input dropped from the tally.
- Without a `daReader`, `prepareBallot` asks the server (needs `serverUrl`). With neither, it treats
  the slot as empty only when `getSlotStatus` finds no entry, and throws on an occupied slot.
- The BFV commitment is recomputed with the registered preset, so register the round's preset first,
  as for any ballot.

## API

### CrispSDK Class

- `constructor(serverUrl?: string | null, rpcUrl?: string | null)` or
  `constructor({ serverUrl?, rpcUrl?, daReader? })` - Create a new SDK instance. Without a
  `serverUrl`, methods that call the CRISP server throw. With a `daReader`, `prepareBallot` resolves
  the slot head from the chain instead of the server.
- `generateVoteProof(voteProofRequest: VoteProofRequest): Promise<ProofData>` - Generate a vote
  proof (automatically handles previous ciphertext)
- `generateMaskVoteProof(maskVoteProofRequest: MaskVoteProofRequest): Promise<ProofData>` - Generate
  a mask vote proof (automatically handles previous ciphertext)

### State Functions

- `getRoundDetails(serverUrl: string, e3Id: bigint): Promise<RoundDetails>` - Get round details
- `getRoundTokenDetails(serverUrl: string, e3Id: bigint): Promise<TokenDetails>` - Get token details
  for a round
- `getPreviousCiphertext(serverUrl: string, e3Id: bigint, address: string): Promise<SlotHead | undefined>` -
  Get the end of a slot's chain of usable entries, as `{ ciphertext, index }`. `index` is what a new
  input names as its parent. Undefined when the slot holds nothing usable.

### Chain Read Functions

Read straight from the chain; no CRISP server. The chain reads take `rpcUrl` (optional).
`getPublicClient`, `getRoundState`, `getRoundBfvParams`, `getCommitteePublicKeyCandidates`,
`getSlotStatus`, `getInputStartBlock`, `scanLogs` and `blockAtTimestamp` are also exported from the
light `@crisp-e3/sdk/chain` entry; the rest are in the main entry only.

- `getRoundState({ interfoldAddress, e3Id, chainId, rpcUrl?, now? }): Promise<RoundState>` - The
  round's stage, input window, commitment deadline, request time, key commitment, parameter set and
  program, and `acceptingInputs`.
- `getRoundBfvParams(options): Promise<RoundBfvParams>` - The round's BFV parameters from
  `paramSetRegistry`.
- `getCommitteePublicKeyCandidates({ ...round, fromBlock?, toBlock?, maxCandidates? }): Promise<CommitteePublicKeyCandidate[]>` -
  The unverified key candidates announced on the ciphernode registry, deduplicated and capped.
- `getCommitteePublicKey({ ...round, fromBlock?, toBlock?, maxCandidates? }): Promise<Uint8Array>` -
  The candidate whose BFV commitment equals the on-chain one (main entry only; it needs wasm).
- `getSlotStatus({ programAddress, e3Id, slot, chainId, rpcUrl?, fromBlock?, toBlock? }): Promise<SlotStatus>` -
  `{ active, entries }` from the slot's `InputCommitted` events.
- `getInputStartBlock({ programAddress, e3Id, chainId, rpcUrl? }): Promise<bigint>` - The block at
  which the round's input window opened.
- `scanLogs(client, { address, event, args?, fromBlock, toBlock?, chunkSize? })` and
  `blockAtTimestamp(client, timestamp)` - Chunked `eth_getLogs`, and the first block at or after a
  unix timestamp.
- `getSlotHead({ programAddress, e3Id, slot, chainId, rpcUrl?, daReader, fromBlock?, toBlock?, chunkSize? }): Promise<SlotHead | undefined>` -
  The slot head from the chain and a `DaReader`, with the Secure Process's rule (main entry only; it
  needs wasm). Same answer as the server's `previous-ciphertext`.
- `getSlotEntries(options): Promise<SlotEntry[]>` - The slot's entries merged from `InputCommitted`
  and `InputPublished`, by tree index.
- `chainHeadPerSlot(entries, isUsable)` and `slotHeadIndex(entries, slot, isUsable)` - The pure head
  rule, with no I/O.
- `createAvailDaReader({ rpcUrl, timeoutMs? })`, `createHttpDaReader(baseUrl, { timeoutMs? })`,
  `createFallbackDaReader(...readers)` and `readVerified(reader, entry)` - Ciphertext readers, and
  the hash check every byte goes through. Each request times out after `timeoutMs` (default 15000),
  so a hung store fails and the fallback moves on.

### Token Functions

- `getBalanceAt(voterAddress: string, tokenAddress: string, snapshotBlock: number, chainId: number): Promise<bigint>` -
  Get token balance at a specific block
- `getTotalSupplyAt(tokenAddress: string, snapshotBlock: number, chainId: number): Promise<bigint>` -
  Get total supply at a specific block
- `getTreeData(serverUrl: string, e3Id: bigint): Promise<bigint[]>` - Get merkle tree leaves from
  server

### Vote Functions

- `generateVoteProof(voteProofInputs: VoteProofInputs): Promise<ProofData>` - Generate a vote proof
  (low-level)
- `generateMaskVoteProof(maskVoteProofInputs: MaskVoteProofInputs): Promise<ProofData>` - Generate a
  mask vote proof (low-level)
- `verifyProof(proof: ProofData): Promise<boolean>` - Verify a proof locally
- `encodeVote(vote: Vote): number[]` - Encode one weight per option into message coefficients,
  padded to the BFV degree
- `decodeTally(tallyBytes: string | number[] | bigint[], numChoices: number): TallyResult` - Decode
  the first `numChoices` coefficients of a tally into one total per option
- `validateVote(vote: Vote, balance: bigint): void` - Check the weights against the plaintext
  modulus and the voting-power rules; throws on an invalid vote
- `generatePublicKey(): Uint8Array` - Generate a random public key
- `encryptVote(vote: Vote, publicKey: Uint8Array): Uint8Array` - Encrypt a vote
- `encodeSolidityProof(proof: ProofData): Hex` - Encode proof for Solidity contract
- `decodeInputIdentity(encodedProof: Hex): InputIdentity` - Read the slot address, ciphertext
  commitment, ciphertext hash, and parent index plus one from an `encodeSolidityProof` envelope

### Submission Functions

- `getInputSelection(serverUrl: string, e3Id: bigint, identity: InputIdentity): Promise<InputSelectionResponse | undefined>` -
  Get the Secure Process selection state of an input. Undefined when the server has no record of the
  round.
- `getSubmissionStage(inputs: SubmissionStageInputs): SubmissionStatus` - Combine the availability
  job status and the selection state into the stage of one ballot, and tell whether a retry is
  offered

### Utility Functions

- `generateMerkleProof(balance: bigint, address: string, leaves: bigint[] | string[]): MerkleProof` -
  Generate merkle proof
- `generateMerkleTree(leaves: bigint[]): LeanIMT` - Generate merkle tree
- `hashLeaf(address: string, balance: bigint): bigint` - Hash a leaf node
- `getAddressFromSignature(signature: \`0x${string}\`, messageHash?: \`0x${string}\`):
  Promise<string>` - Extract address from signature

### Constants

- `MERKLE_TREE_MAX_DEPTH` - Maximum depth of the merkle tree
- `SIGNATURE_MESSAGE` - Message used for signature verification
- `MAX_VOTE_OPTIONS` - Maximum number of options in a round
- `MAX_MSG_NON_ZERO_COEFFS` - Number of plaintext coefficients published as the tally
- `SIGNATURE_MESSAGE_HASH` - Hash of the signature message
- `PROOF_STAGES` - The ballot proof stages in the order they run

### Types

- `RoundDetails` - Round details type
- `RoundDetailsResponse` - Server response type for round details
- `TokenDetails` - Token details type
- `Vote` - One non-negative integer weight per option, indexed by option
- `MaskVoteProofInputs` - Inputs for mask vote proof generation
- `VoteProofInputs` - Inputs for vote proof generation
